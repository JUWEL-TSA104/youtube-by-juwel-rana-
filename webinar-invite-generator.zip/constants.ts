import { SpeakerProfile } from './types';

export const SPEAKER_PROFILES: SpeakerProfile[] = [
  {
    id: 'ashika',
    speaker: "ASHIKA YEASMIN",
    host: "TAHMIDUR RAHMAN",
    topic: "DIGITAL EARNING OPPORTUNITY",
    title: "Trainer"
  },
  {
    id: 'shohid',
    speaker: "SHOHID UDDIN",
    host: "AKRIZA SULTANA",
    topic: "INDUSTY INTRODUCTION",
    title: "Trainer"
  },
  {
    id: 'ruth',
    speaker: "RUTH CHOWDHURY",
    host: "TAHMIDUR RAHMAN",
    topic: "FOREVER MARKETING PLAN",
    title: "Trainer"
  },
  {
    id: 'sinthia',
    speaker: "Sinthia Asha",
    host: "Tahmidur Rahman",
    topic: "Product knowledge",
    title: "Trainer"
  },
  {
    id: 'shahid_study',
    speaker: "Shahid Uddin",
    host: "shahnaj sahin",
    topic: "How to study your business",
    title: "Trainer"
  },
  {
    id: 'ayon',
    speaker: "Ayon Jahir",
    host: "Sumaiya",
    topic: "WHY NOT FOREVER LIVINIG PRODUCTS?",
    title: "Trainer"
  }
];

// Helper to get today's date in YYYY-MM-DD format
const getTodayDate = () => {
  return new Date().toISOString().split('T')[0];
};

export const INITIAL_FORM_DATA = {
  topic: "DIGITAL EARNING OPPORTUNITY",
  hostName: "TAHMIDUR RAHMAN",
  speakerName: "ASHIKA YEASMIN",
  speakerTitle: "Trainer",
  link: "https://youtu.be/TC_IA3Jc2OU",
  date: getTodayDate(), 
  time: "21:00" // 9:00 PM in 24h format
};