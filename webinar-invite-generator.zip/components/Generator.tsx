import React, { useState, useEffect } from 'react';
import { Copy, Check, User, Users, Calendar, Clock, Link as LinkIcon, Briefcase, FileText, Globe } from 'lucide-react';
import { SPEAKER_PROFILES, INITIAL_FORM_DATA } from '../constants';
import { FormData } from '../types';

// Helper to format date like "26th May, 2023"
const formatDateForPreview = (dateStr: string) => {
  if (!dateStr) return '';
  const d = new Date(dateStr);
  if (isNaN(d.getTime())) return dateStr; // Fallback if invalid
  const day = d.getDate();
  const month = d.toLocaleString('en-US', { month: 'long' });
  const year = d.getFullYear();

  const getOrdinal = (n: number) => {
    if (n > 3 && n < 21) return 'th';
    switch (n % 10) {
      case 1:  return "st";
      case 2:  return "nd";
      case 3:  return "rd";
      default: return "th";
    }
  };

  return `${day}${getOrdinal(day)} ${month}, ${year}`;
};

// Helper to format time like "9PM" or "9:30PM"
const formatTimeForPreview = (timeStr: string) => {
  if (!timeStr) return '';
  const [hStr, mStr] = timeStr.split(':');
  const h = parseInt(hStr, 10);
  const m = parseInt(mStr, 10);
  
  if (isNaN(h) || isNaN(m)) return timeStr;

  const ampm = h >= 12 ? 'PM' : 'AM';
  const h12 = h % 12 || 12;
  
  if (m === 0) return `${h12}${ampm}`;
  return `${h12}:${m.toString().padStart(2, '0')}${ampm}`;
};

export const Generator: React.FC = () => {
  // Live Clock State
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const [formData, setFormData] = useState<FormData>(INITIAL_FORM_DATA);
  const [selectedProfileId, setSelectedProfileId] = useState<string>('ashika');
  const [copied, setCopied] = useState(false);

  // Handle speaker selection change
  const handleProfileChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const profileId = e.target.value;
    setSelectedProfileId(profileId);

    if (profileId === 'custom') {
      return;
    }

    const profile = SPEAKER_PROFILES.find(p => p.id === profileId);
    if (profile) {
      setFormData(prev => ({
        ...prev,
        speakerName: profile.speaker,
        hostName: profile.host,
        topic: profile.topic,
        speakerTitle: profile.title || prev.speakerTitle
      }));
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // If user manually changes speaker, host, or topic, switch dropdown to custom
    if (['speakerName', 'hostName', 'topic'].includes(name)) {
      setSelectedProfileId('custom');
    }
  };

  const generateTemplate = () => {
    const formattedDate = formatDateForPreview(formData.date);
    const formattedTime = formatTimeForPreview(formData.time);

    return `✅PERSONAL GUIDELINE✨

🎯Get Ready To Become a Business Owner🎀

🎯🎯Topic:   🌠${formData.topic}

‼️Congratulations‼️
You're Selected To Attend This 
Webinar❤️‍🔥❤️‍🔥❤️‍🔥

                Host🥀
🎤${formData.hostName}

          Speaker🥀
🎤${formData.speakerName}
     ${formData.speakerTitle}

🗣️We are inviting you to a schedule YouTube premier ‼️

📲Join Youtube premier👇

${formData.link}

     Date: "${formattedDate}"
  ⏰⏰⏰START AT ${formattedTime}‼️

Participate On Time Everyone & Don't Miss This Opportunity💯`;
  };

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(generateTemplate());
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy text: ', err);
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      {/* Header with Clock */}
      <header className="mb-10 text-center relative">
        <div className="absolute top-0 right-0 hidden md:flex items-center gap-2 bg-white/80 backdrop-blur px-4 py-2 rounded-full shadow-sm text-sm font-mono text-purple-700 border border-purple-100">
          <Globe size={16} />
          <span>{currentTime.toLocaleTimeString('en-US', { hour12: true })}</span>
        </div>
        
        <h1 className="text-4xl md:text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-pink-600 mb-3 pt-8 md:pt-0">
          Webinar Invite Generator
        </h1>
        <p className="text-gray-600 text-lg">Select a speaker to automatically set the host and topic.</p>
        
        {/* Mobile Clock */}
        <div className="md:hidden mt-4 inline-flex items-center gap-2 bg-white/80 px-4 py-1 rounded-full text-sm font-mono text-purple-700 shadow-sm">
          <Clock size={14} />
          {currentTime.toLocaleTimeString('en-US', { hour12: true })}
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
        
        {/* Left Column: Form */}
        <div className="bg-white/90 backdrop-blur-sm rounded-2xl p-6 shadow-xl border border-white/50">
          <div className="flex items-center gap-2 mb-6 border-b border-gray-100 pb-4">
            <div className="bg-purple-100 p-2 rounded-lg">
              <Users className="h-6 w-6 text-purple-600" />
            </div>
            <h2 className="text-xl font-bold text-gray-800">Configuration</h2>
          </div>

          <div className="space-y-5">
            {/* Profile Selector */}
            <div className="space-y-2">
              <label className="text-sm font-bold text-gray-700 block">Select Speaker</label>
              <div className="relative">
                <select
                  value={selectedProfileId}
                  onChange={handleProfileChange}
                  className="w-full px-4 py-3 rounded-xl border border-gray-300 bg-white focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all appearance-none text-gray-700 font-medium"
                >
                  <optgroup label="Select Speaker">
                    {SPEAKER_PROFILES.map(profile => (
                      <option key={profile.id} value={profile.id}>
                        {profile.speaker}
                      </option>
                    ))}
                  </optgroup>
                  <option value="custom">-- Custom / Manual Entry --</option>
                </select>
                <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-4 text-gray-500">
                  <svg className="h-4 w-4 fill-current" viewBox="0 0 20 20">
                    <path d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" />
                  </svg>
                </div>
              </div>
            </div>

            <div className="h-px bg-gray-200 my-4" />

            {/* Editable Fields */}
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                 <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide flex items-center gap-1">
                    <User size={14} /> Speaker Name
                  </label>
                  <input
                    type="text"
                    name="speakerName"
                    value={formData.speakerName}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-purple-400 focus:border-transparent outline-none transition-all"
                  />
                </div>
                 <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide flex items-center gap-1">
                    <Briefcase size={14} /> Speaker Title
                  </label>
                  <input
                    type="text"
                    name="speakerTitle"
                    value={formData.speakerTitle}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-purple-400 focus:border-transparent outline-none transition-all"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide flex items-center gap-1">
                  <Users size={14} /> Host Name
                </label>
                <input
                  type="text"
                  name="hostName"
                  value={formData.hostName}
                  onChange={handleInputChange}
                  className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-purple-400 focus:border-transparent outline-none transition-all"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide flex items-center gap-1">
                  <FileText size={14} /> Topic
                </label>
                <input
                  type="text"
                  name="topic"
                  value={formData.topic}
                  onChange={handleInputChange}
                  className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-purple-400 focus:border-transparent outline-none transition-all"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide flex items-center gap-1">
                  <LinkIcon size={14} /> Webinar Link
                </label>
                <input
                  type="text"
                  name="link"
                  value={formData.link}
                  onChange={handleInputChange}
                  className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-purple-400 focus:border-transparent outline-none transition-all text-blue-600"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide flex items-center gap-1">
                    <Calendar size={14} /> Date
                  </label>
                  <input
                    type="date"
                    name="date"
                    value={formData.date}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-purple-400 focus:border-transparent outline-none transition-all font-mono text-sm"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide flex items-center gap-1">
                    <Clock size={14} /> Time
                  </label>
                  <input
                    type="time"
                    name="time"
                    value={formData.time}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-purple-400 focus:border-transparent outline-none transition-all font-mono text-sm"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Preview */}
        <div className="flex flex-col h-full shadow-2xl rounded-2xl overflow-hidden bg-white">
          <div className="bg-gradient-to-r from-gray-900 to-gray-800 text-white p-4 flex justify-between items-center">
            <h2 className="font-bold flex items-center gap-2">
              <FileText className="h-5 w-5 text-purple-400" />
              Live Preview
            </h2>
            <span className="text-xs bg-gray-700 px-2 py-1 rounded text-gray-300 font-mono">Auto-updates</span>
          </div>

          <div className="flex-1 bg-gray-100 flex flex-col relative">
            <textarea 
              readOnly
              value={generateTemplate()}
              className="flex-1 p-6 m-0 w-full h-[500px] lg:h-auto text-sm leading-relaxed text-gray-900 bg-gray-50 resize-none outline-none font-mono border-none"
              spellCheck={false}
            />
            
            <div className="absolute bottom-4 right-4 left-4">
               <button 
                onClick={copyToClipboard}
                className={`w-full py-4 px-6 rounded-xl font-bold text-lg shadow-lg flex items-center justify-center gap-3 transition-all duration-300 transform active:scale-95 ${
                  copied 
                    ? 'bg-green-500 text-white hover:bg-green-600' 
                    : 'bg-gradient-to-r from-purple-600 to-pink-600 text-white hover:from-purple-700 hover:to-pink-700'
                }`}
              >
                {copied ? <Check className="h-6 w-6" /> : <Copy className="h-6 w-6" />}
                <span>{copied ? "Copied to Clipboard!" : "Copy Invitation Text"}</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
