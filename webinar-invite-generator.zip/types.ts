export interface SpeakerProfile {
  id: string;
  speaker: string;
  host: string;
  topic: string;
  title?: string;
}

export interface FormData {
  topic: string;
  hostName: string;
  speakerName: string;
  speakerTitle: string;
  link: string;
  date: string;
  time: string;
}
