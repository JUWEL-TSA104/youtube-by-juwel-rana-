import React from 'react';
import { Generator } from './components/Generator';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-100 via-purple-100 to-pink-100 font-sans text-gray-800">
      <Generator />
    </div>
  );
}

export default App;
